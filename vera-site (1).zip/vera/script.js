/* ==========================================================
   VERA — settings you can edit
   ========================================================== */
const VERA = {
  // WhatsApp number in international format, digits only. Example (Egypt): "201012345678"
  // Leave it empty ("") and the order buttons will open an Instagram DM instead.
  whatsapp: "",
  instagram: "vera_no.0",
};

/* ---------- Order buttons ---------- */
(function () {
  const buttons = document.querySelectorAll("[data-order]");
  if (!buttons.length) return;

  const igDm = "https://ig.me/m/" + VERA.instagram;

  function selectedSize() {
    const checked = document.querySelector('input[name="size"]:checked');
    return checked ? checked.value : "";
  }

  function build(btn) {
    const product = btn.getAttribute("data-order");
    if (!VERA.whatsapp) return igDm;
    const size = selectedSize();
    const text =
      "مرحبًا VERA 👋\nحابة أطلب: " + product + (size ? "\nالمقاس: " + size : "") + "\nالصفحة: " + location.href;
    return "https://wa.me/" + VERA.whatsapp + "?text=" + encodeURIComponent(text);
  }

  function refresh() {
    buttons.forEach(function (b) {
      b.href = build(b);
      b.target = "_blank";
      b.rel = "noopener";
    });
  }

  document.querySelectorAll('input[name="size"]').forEach(function (i) {
    i.addEventListener("change", refresh);
  });
  refresh();
})();

/* ---------- Generic contact links (footer, home) ---------- */
(function () {
  document.querySelectorAll("[data-wa]").forEach(function (a) {
    if (VERA.whatsapp) {
      a.href = "https://wa.me/" + VERA.whatsapp;
      a.target = "_blank";
      a.rel = "noopener";
    } else {
      a.href = "https://ig.me/m/" + VERA.instagram;
    }
  });
  document.querySelectorAll("[data-year]").forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });
})();
